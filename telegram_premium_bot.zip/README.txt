README.txt

Telegram Bot for Premium Video Access

1. Install requirements:
   pip install aiogram

2. Run the bot:
   python main.py

3. Edit 'https://t.me/+YourPrivateInvite' with your actual private channel invite link.
